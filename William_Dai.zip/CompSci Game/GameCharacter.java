import java.awt.*;

class GameCharacter implements Draw{
    private int userX;
    private int userY;
    private int speed;
    private int defSpeed;
    private int sprintBonus;
    
    GameCharacter(){
        this.userX = 310;
        this.userY = GameConst.CHARACTER_Y;
        this.defSpeed = GameConst.CHARACTER_SPEED;
        this.sprintBonus = GameConst.CHARACTER_SPRINT_SPEED;
        this.speed = defSpeed;
    }
    public int getX(){
        return this.userX;
    }
    public int getHitX(){
        return this.userX-5;
    }
    public int getHitY(){
        return this.userY-80;
    }
    public int getHitLength(){
        return 115;
    }
    public int getHitWidth(){
        return 15;
    }
    public int getCharCenter(){
        return getHitX()+50;
    }
    public void moveLeft(){
        this.userX-=this.speed;
    }
    public void moveRight(){
        this.userX+=this.speed;
    }
    public void sprintLeft(){
        this.userX-=this.sprintBonus;
    }
    public void sprintRight(){
        this.userX+=this.sprintBonus;
    }
    public void sprint(boolean sprint){
        if(sprint){
            this.speed = this.sprintBonus;
        } else {
            this.speed = this.defSpeed;
        }
    }
        public void draw(Graphics g) {
            g.setColor(Color.BLACK);
            g.fillPolygon(new int[]{this.userX+26, this.userX+60, this.userX+94}, new int[]{this.userY, this.userY-54, this.userY}, 3);
            g.fillOval(this.userX+30, this.userY-65, 60, 60);
            g.fillRect(this.userX+15, this.userY-35, 90, 25);
            g.fillRect(this.userX+15, this.userY-80, 25, 70);
            g.fillRect(this.userX+81, this.userY-80, 25, 70);
            g.setColor(Color.DARK_GRAY);
            g.fillPolygon(new int[]{this.userX+30, this.userX+60, this.userX+90}, new int[]{this.userY, this.userY-50, this.userY}, 3);
            g.fillOval(this.userX+35, this.userY-60, 50, 50);
            g.fillRect(this.userX+20, this.userY-30, 80, 15);
            g.fillRect(this.userX+20, this.userY-75, 15, 60);
            g.fillRect(this.userX+86, this.userY-75, 15, 60);
            g.setColor(Color.BLACK);
            g.fillRect(this.userX+5, this.userY-85, 110, 20);
            g.setColor(Color.WHITE);
            g.fillRect(this.userX+10, this.userY-80, 100, 10);
            g.setColor(Color.RED);
            g.fillRect(this.userX+10, this.userY-80, 100, 2);
            if(this.userX <= 310){
                this.userX = 310;
            }
            if(this.userX >= 470){
                this.userX = 470;
            }
    }
}