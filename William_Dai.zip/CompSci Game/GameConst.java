import java.awt.*;

public final class GameConst{
    public static final int FRAME_WIDTH = 900;
    public static final int FRAME_HEIGHT = 700;
    public static final int LARGE_FONT_SIZE = 40;
    public static final int NORMAL_FONT_SIZE = 24;
    public static final int SMALL_FONT_SIZE = 18;
    public static final String FONT = "Courier New";
    public static final Color DARK_GREY = new Color(51, 51, 51);
    public static final Color LIGHT_BLUE = new Color(51, 153, 255);
    
    public static final int GAME_BOX_SETX = 320;
    public static final int GAME_BOX_SETY = 50;
    public static final int GAME_BOX_BASE = 260;
    public static final int GAME_BOX_HEIGHT = 565;

    public static final int LEFT_DISPLAY_SETX = 70;
    public static final int RIGHT_DISPLAY_SETX = 630;
    public static final int DEF_DISPLAY_BASE = 200;
    public static final int DEF_DISPLAY_HEIGHT = 50;
    public static final int HS_DISPLAY_HEIGHT = 200;
    public static final int DEF_SPRINT_BAR_LENGTH = 188;
    
    public static final int SCORE_BAR_SETY = 575;
    public static final int TIME_BAR_SETY = 575;
    public static final int LEVEL_BAR_SETY = 80;
    public static final int LIFE_BAR_SETY = 160;
    public static final int HIGHSCORE_BAR_SETY = 80;
    public static final int SPRINT_BAR_SETY = 400;
    
    public static final int CHARACTER_Y = 615;
    public static final int CHARACTER_SPEED = 5;
    public static final int CHARACTER_SPRINT_SPEED = 3;

    public static final int BASIC_ITEM_VALUE = 10;
    public static final int MOVING_ITEM_VALUE = 12;
    public static final int DAMAGE_ITEM_VALUE = -15;
    public static final int HOMING_ITEM_VALUE = -10;
    public static final int DEF_ITEM_SIZE = 20;

    public static final int LASER_WIDTH = 12;
    public static final int LASER_DELAY = 75;
    public static final int LASER_APPEARANCE_TIME = 100;

    public static final int NO_MOVE_AREA_DROP_DELAY = 25;
    
    private GameConst(){
    }
}