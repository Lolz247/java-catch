import java.awt.*;

interface Draw{
    public void draw(Graphics g);
}