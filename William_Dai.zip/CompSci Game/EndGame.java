import java.awt.*;

class EndGame implements Draw{
    private int score;
    private int time;
    private boolean highscore;
    private int largeFontSize;
    private int textFontSize;
    private String fontName;
    
    EndGame(){
        this.largeFontSize = GameConst.LARGE_FONT_SIZE;
        this.textFontSize = GameConst.NORMAL_FONT_SIZE;
        this.fontName = GameConst.FONT;
    }
    public void setScore(GameScore other){
        this.score = other.getScore();
    }
    public void setTime(GameTime other){
        this.time = (int)other.getTimeElapsed();
    }
    public void checkHighscore(HighscoreBoard other){
        this.highscore = other.getCheckHighscore();
    }
    public void draw(Graphics g) {
        g.setColor(Color.black);
        g.fillRect(290, 190, 320, 320);
        g.setColor(Color.white);
        g.fillRect(302, 202, 296, 296);
        g.setColor(Color.black);
        g.fillRect(312, 212, 276, 276);
        g.setColor(Color.WHITE);

        Font headerFont = new Font(this.fontName, Font.BOLD, this.largeFontSize);
        g.setFont(headerFont);
        g.drawString("GAME OVER", 342, 280);
        Font textFont = new Font(this.fontName, Font.PLAIN, this.textFontSize);
        g.setFont(textFont);
        g.drawString("SCORE: "+this.score, 370, 320);
        g.drawString("TIME:  "+this.time, 370, 360);
        if(highscore){
            g.setColor(Color.YELLOW);
            Font subheaderFont = new Font(this.fontName, Font.BOLD, this.textFontSize);
            g.setFont(subheaderFont);
            g.drawString("NEW HIGHSCORE!", 355, 430);
        }
    }
}