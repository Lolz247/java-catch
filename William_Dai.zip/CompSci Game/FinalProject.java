class FinalProject{
    public static void main(String[] args) throws Exception{
        GameGame game = new GameGame();
        game.setUp();
        game.runGameLoop();
    }
}