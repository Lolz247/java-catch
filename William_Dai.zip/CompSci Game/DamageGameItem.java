import java.awt.*;

public class DamageGameItem extends GameItem{
    int itemY;
    DamageGameItem(int level){
        super(level, GameConst.DAMAGE_ITEM_VALUE, 0, Color.RED);
        this.itemX = (int)((Math.random()*(GameConst.GAME_BOX_BASE-20))+GameConst.GAME_BOX_SETX);
        this.itemY = GameConst.GAME_BOX_SETY;
    }
}