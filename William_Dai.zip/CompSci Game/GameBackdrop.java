import java.awt.*;

public class GameBackdrop implements Draw{
    private int gameBoxX;
    private int gameBoxY;
    private int gameBoxBase;
    private int gameBoxHeight;    
    //constructor
    public GameBackdrop(){
        this.gameBoxX = GameConst.GAME_BOX_SETX;
        this.gameBoxY = GameConst.GAME_BOX_SETY;
        this.gameBoxBase = GameConst.GAME_BOX_BASE;
        this.gameBoxHeight = GameConst.GAME_BOX_HEIGHT;
    }
    public int getGroundX(){
        return 310;
    }
    public int getGroundY(){
        return 635;
    }
    public int getGroundLength(){
        return 260;
    }
    public void draw(Graphics g){
        //set backdrop
        g.setColor(Color.black);
        g.fillRect(0, 0, 900, 700);
        //create game template
        g.setColor(Color.white);
        g.fillRect(this.gameBoxX-10, this.gameBoxY-10, this.gameBoxBase+20, this.gameBoxHeight+20);
        g.setColor(Color.black);
        g.fillRect(this.gameBoxX, this.gameBoxY, this.gameBoxBase, this.gameBoxHeight);
    }
}