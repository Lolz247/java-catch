import java.awt.*;

public class BasicGameItem extends GameItem{
    int itemY;
    BasicGameItem(int level){
        super(level, GameConst.BASIC_ITEM_VALUE, 0, Color.WHITE);
        this.itemX = (int)((Math.random()*(GameConst.GAME_BOX_BASE-20))+GameConst.GAME_BOX_SETX);
        this.itemY = GameConst.GAME_BOX_SETY;
    }
}