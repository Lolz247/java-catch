import java.awt.*;

public class DisplayBar implements Draw{
    private int fontSize;
    private String fontName;
    private int setX;
    private int setY;
    private int base;
    private int height;
    private String displayText;
    private String labelText;
    
    public DisplayBar(int setX, int setY, String displayText, String labelText) {
        this.fontSize = GameConst.NORMAL_FONT_SIZE;
        this.fontName = GameConst.FONT;
        this.setX = setX;
        this.setY = setY;
        this.base = GameConst.DEF_DISPLAY_BASE;
        this.height = GameConst.DEF_DISPLAY_HEIGHT;
        this.displayText = displayText;
        this.labelText = labelText;
    }
    
    public int setHeight(int height){
        this.height = height;
        return this.height;
    }
    public void draw(Graphics g) {
        
        g.setColor(Color.white);
        g.fillRect(this.setX, this.setY, this.base, this.height);
        g.setColor(Color.black);
        g.fillRect(this.setX+6, this.setY+6, this.base-12, this.height-12);
        g.setColor(Color.white);
        
        Font textFont = new Font(fontName, Font.PLAIN, fontSize);
        g.setFont(textFont);
        g.drawString(this.displayText, setX+15, setY+32);
        g.drawString(this.labelText, setX+10, setY-5);
    }
}