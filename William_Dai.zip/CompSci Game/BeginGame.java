import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BeginGame implements Draw{
    JFrame panelFrame;
    private int frameWidth;
    private int frameHeight;
    private int largeFontSize;
    private int textFontSize;
    private String fontName;
    JPanel panel;
    JTextField inputField;
    JLabel messageLabel;
    JButton enterButton;
    private String username;
    private boolean canStart;
    private boolean startGame;
    private boolean keepMenu;
    private boolean openGuide;
    //constructor
    BeginGame() {
        this.panelFrame = new JFrame();
        this.frameWidth = 300;
        this.frameHeight = 200;
        this.largeFontSize = GameConst.LARGE_FONT_SIZE;
        this.textFontSize = GameConst.NORMAL_FONT_SIZE;
        this.fontName = GameConst.FONT;
        //initializing JPanel
        this.inputField = new JTextField(5);
        this.messageLabel = new JLabel("Initials: ");
        this.enterButton = new JButton("Enter");
        this.panel = new JPanel();
        this.panel.setLayout(new GridLayout(0, 1));
        this.username = "";
        this.canStart = false;
        this.startGame = false;
        this.keepMenu = true;
        this.openGuide = false;
    }
    //getters
    public String getName(){
        return this.username;
    }
    public boolean canStart(){
        return this.canStart;
    }
    public boolean getStartGame(){
        return this.startGame;
    }
    public boolean getKeepMenu(){
        return this.keepMenu;
    }
    public boolean getOpenGuide(){
        return this.openGuide;
    }
    //setters
    public void setKeepMenu(boolean keep){
        this.keepMenu = keep;
    }
    public void setStartGame(boolean start){
        this.startGame = start;
    }
    public void setOpenGuide(boolean open){
        this.openGuide = open;
    }
    public void setCanStart(boolean started){
        this.canStart = started;
    }
    public void createPanel(){
        this.panelFrame.setSize(frameWidth, frameHeight);
        this.panelFrame.setLocationRelativeTo(null);
        this.panelFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        this.panel.add(messageLabel);
        this.panel.add(inputField);
        this.panel.add(enterButton);
        this.enterButton.addActionListener(new EnterButtonListener());
        this.panelFrame.add(panel);
        this.panelFrame.setVisible(true);
    }
    //---------------------------------------------------------------------------
    public class EnterButtonListener implements ActionListener{
        public void actionPerformed(ActionEvent event){
            String userInitials = inputField.getText();
            int count = 0;
            //checks for valid initials
            do{
                for(int i=0;i<userInitials.length();i++){
                    if(userInitials.charAt(i) == ' '){
                        count++;
                    }
                }
                if(count == 0 && userInitials.length() != 0) { 
                    username = inputField.getText();
                    canStart = true;
                    panelFrame.dispose();
                } else {
                    messageLabel.setText("Invalid Input");
                    count = 0;
                }
            } while(count > 0);
        }
    }
    //---------------------------------------------------------------------------
    public void draw(Graphics g) {
        g.setColor(Color.black);
        g.fillRect(290, 190, 320, 320);
        g.setColor(Color.white);
        g.fillRect(302, 202, 296, 296);
        g.setColor(Color.black);
        g.fillRect(312, 212, 276, 276);
        
        g.setColor(Color.white);
        Font headerFont = new Font(this.fontName, Font.BOLD, this.largeFontSize);
        g.setFont(headerFont);
        g.drawString("java!catch", 328, 270);
        Font textFont = new Font(this.fontName, Font.BOLD, this.textFontSize);
        g.setFont(textFont);
        g.drawString("GUIDE      [H]", 340, 350);
        g.drawString("START    [SPACE]", 340, 410);
    }
}